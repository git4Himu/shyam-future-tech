const environment = {
  baseUrl: "https://webskiter-f5c32-default-rtdb.firebaseio.com",
};

export default environment;
